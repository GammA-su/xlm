﻿import json
import statistics
import subprocess
import sys
import time
from pathlib import Path
rows=[]
for module in ('', 'torch', 'pyarrow', 'datasets', 'lm_eval', 'xlm.cli.main'):
 for repeat in range(3):
  argv=[sys.executable,'-c', 'import importlib,sys; importlib.import_module(sys.argv[1])' if module else 'pass']
  if module:argv.append(module)
  started=time.perf_counter()
  result=subprocess.run(argv,capture_output=True,text=True,timeout=30)
  rows.append({'module':module or 'bare_python','repetition':repeat,'argv':argv,'elapsed_seconds':time.perf_counter()-started,'exit_code':result.returncode,'stderr':result.stderr})
  if result.returncode:raise RuntimeError(result.stderr)
Path('artifacts/test-suite-perf-p30b/imports-unprofiled.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
for module in dict.fromkeys(row['module'] for row in rows):
 print(module,statistics.median(row['elapsed_seconds'] for row in rows if row['module']==module))
