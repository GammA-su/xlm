"""P30B read-only setup profile. Run after the serial baseline completes."""
import cProfile
import importlib
import json
import os
from pathlib import Path
import pstats
import statistics
import subprocess
import sys
import time

import psutil

ROOT = Path.cwd()
OUT = ROOT / 'artifacts/test-suite-perf-p30b'


def child(case):
    started = time.perf_counter()
    profile = cProfile.Profile()
    profile.enable()
    result = None
    if case == 'inventory':
        from xlm.experiments.environment import installed_runtime
        result = installed_runtime(ROOT / 'uv.lock', ['cpu'])
    elif case == 'frozen_fixture':
        sys.path.insert(0, str(ROOT / 'tests'))
        from test_frozen_execution import frozen_fixture
        path = OUT / ('profile-frozen-' + str(os.getpid()))
        path.mkdir()
        plan, _, _, _, _ = frozen_fixture(path)
        result = plan.execution_envelope['environment']
    elif case != 'empty':
        importlib.import_module(case)
    profile.disable()
    elapsed = time.perf_counter() - started
    stats = pstats.Stats(profile)
    rows = []
    for (file, line, name), (primitive, calls, self_s, cumulative_s, callers) in stats.stats.items():
        if any(word in file for word in ('xlm', 'importlib', 'threading', 'metadata', 'hashlib', 'concurrent')):
            rows.append(dict(file=file, line=line, name=name, calls=calls, self_seconds=self_s, cumulative_seconds=cumulative_s))
    rows.sort(key=lambda row: row['cumulative_seconds'], reverse=True)
    profile.dump_stats(str(OUT / f'profile-{case}-{os.getpid()}.pstats'))
    print(json.dumps(dict(case=case, useful_seconds=elapsed, result=result, top_functions=rows[:80])))


def main():
    results = []
    for repetition in range(3):
        start = time.perf_counter()
        bare = subprocess.run([sys.executable, '-c', 'pass'], capture_output=True, timeout=10)
        results.append(dict(case='bare_python', repetition=repetition, wall_seconds=time.perf_counter()-start, exit_code=bare.returncode))
    for case in ('empty', 'torch', 'pyarrow', 'datasets', 'lm_eval', 'xlm.cli.main', 'inventory', 'frozen_fixture'):
        repeats = 1 if case in ('inventory', 'frozen_fixture') else 3
        for repetition in range(repeats):
            start = time.perf_counter()
            log = OUT / f'startup-{case}-{repetition}.log'
            error = OUT / f'startup-{case}-{repetition}.err'
            with log.open('w', encoding='utf8') as stdout, error.open('w', encoding='utf8') as stderr:
                process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--child', case], stdout=stdout, stderr=stderr, env=dict(os.environ))
                parent = psutil.Process(process.pid)
                cpu = {}
                peak = peak_processes = 0
                while process.poll() is None:
                    if time.perf_counter() - start > 150:
                        for owned in parent.children(recursive=True):
                            owned.kill()
                        process.kill()
                        raise TimeoutError(case)
                    rss = count = 0
                    try:
                        processes = [parent, *parent.children(recursive=True)]
                    except psutil.NoSuchProcess:
                        processes = []
                    for proc in processes:
                        try:
                            rss += proc.memory_info().rss
                            times = proc.cpu_times()
                            cpu[(proc.pid, proc.create_time())] = times.user + times.system
                            count += 1
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass
                    peak = max(peak, rss)
                    peak_processes = max(peak_processes, count)
                    time.sleep(.05)
            row = dict(case=case, repetition=repetition, wall_seconds=time.perf_counter()-start, exit_code=process.returncode, peak_tree_rss_bytes=peak, sampled_cpu_seconds_lower_bound=sum(cpu.values()), observed_processes=len(cpu), peak_observed_processes=peak_processes)
            if process.returncode == 0:
                row['child'] = json.loads(log.read_text(encoding='utf8').strip().splitlines()[-1])
            results.append(row)
            (OUT / 'startup.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf8')
            print(case, repetition, round(row['wall_seconds'], 3), process.returncode, flush=True)
            if process.returncode:
                raise RuntimeError(f'{case} failed; retained {error}')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        child(sys.argv[2])
    else:
        main()
