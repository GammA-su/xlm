﻿import json
import re
from pathlib import Path
ROOT=Path(r'C:\Users\gamma\AppData\Local\Temp\pytest-of-gamma\pytest-843')
OUT=Path('artifacts/test-suite-perf-p30b')
rows=[]
for path in sorted(ROOT.rglob('process.json')):
 data=json.loads(path.read_text(encoding='utf8'))
 if 'elapsed_seconds' not in data: continue
 row={'path':str(path.relative_to(ROOT)),**data}
 log=path.parent/'stdout.log'
 if log.is_file():
  row['reported_work_times']=re.findall(r'(?:Training Time|Setup Time|Total Steps|Committed Targets):\s+[^\r\n]+',log.read_text(encoding='utf8',errors='replace'))
 rows.append(row)
(OUT/'before-worker-receipts.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
print(len(rows),'completed worker receipts')
