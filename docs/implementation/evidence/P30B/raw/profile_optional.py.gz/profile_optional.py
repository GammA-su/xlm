"""Bounded offline task-index profile; no model execution or dataset acquisition."""
from __future__ import annotations
import cProfile
import json
import os
from pathlib import Path
import pstats
import socket
import time

root = Path.cwd()
out = root / "artifacts/test-suite-perf-p30b"
cache = out / "profile-optional-cache"
for name, path in {"HF_HOME": cache, "HF_HUB_CACHE": cache / "hub", "HF_DATASETS_CACHE": cache / "datasets", "HF_MODULES_CACHE": cache / "modules"}.items():
    os.environ[name] = str(path)
for name in ("HF_HUB_OFFLINE", "HF_DATASETS_OFFLINE", "TRANSFORMERS_OFFLINE"):
    os.environ[name] = "1"

def denied(*args, **kwargs):
    raise RuntimeError("network forbidden in optional setup profile")

socket.socket.connect = denied
from xlm.evaluation.harness import build_task_manager

profile = cProfile.Profile()
start = time.perf_counter()
with profile:
    manager = build_task_manager(root / "fixtures/eval/tasks")
elapsed = time.perf_counter() - start
profile.dump_stats(out / "optional-index.pstats")
stats = pstats.Stats(profile)
rows = []
for (file, line, name), (primitive, calls, own, cumulative, _) in stats.stats.items():
    rows.append({"file": file, "line": line, "function": name, "primitive_calls": primitive, "calls": calls, "own_seconds": own, "cumulative_seconds": cumulative})
rows.sort(key=lambda row: row["cumulative_seconds"], reverse=True)
result = {"wall_seconds": elapsed, "indexed_tasks": len(manager.task_index), "profiled": True, "top50": rows[:50]}
(out / "optional-index.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
print(json.dumps(result, indent=2))
