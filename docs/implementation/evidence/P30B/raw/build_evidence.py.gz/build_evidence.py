﻿"""Build P30B review artifacts from retained measurements; never run tests."""
from __future__ import annotations
import ast
import collections
import csv
import gzip
import hashlib
import json
import re
from pathlib import Path

ROOT=Path.cwd()
RAW=ROOT/'artifacts/test-suite-perf-p30b'
OUT=ROOT/'docs/implementation/evidence/P30B'
OUT.mkdir(parents=True,exist_ok=True)

def decode(path):
 data=path.read_bytes()
 return data.decode('utf-16' if data.startswith(b'\xff\xfe') else 'utf-8',errors='replace')

def normalize(node):return node.rsplit('@p30b-',1)[0]

def outcome(reports):
 if any(r['outcome']=='failed' for r in reports):
  return 'ERROR' if any(r['outcome']=='failed' and r['phase']!='call' for r in reports) else 'FAILED'
 if any(r['outcome']=='skipped' for r in reports):return 'SKIPPED'
 return 'PASSED' if any(r['phase']=='call' and r['outcome']=='passed' for r in reports) else 'MISSING'

runs={}
for path in RAW.glob('*.json'):
 data=json.loads(path.read_text(encoding='utf8'))
 if isinstance(data,dict) and 'reports' in data:runs[path.stem]=data
before=runs['before-serial']
audit=json.loads((RAW/'serial-audit-before.json').read_text())
domains=json.loads((ROOT/'tests/suite_domains.json').read_text())['nodes']
body_checks=[]
for row in audit:
 node=row['nodeid'];module,name=node.split('::',1);name=name.split('[',1)[0]
 tree=ast.parse((ROOT/module).read_text(encoding='utf8'))
 function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
 body=hashlib.sha256(ast.dump(ast.Module(body=function.body,type_ignores=[]),include_attributes=False).encode()).hexdigest()
 assertions=hashlib.sha256('\n'.join(ast.dump(n,include_attributes=False) for n in ast.walk(function) if isinstance(n,ast.Assert)).encode()).hexdigest()
 assert body==row['body_sha256'] and assertions==row['assertions_sha256'],node
 body_checks.append({'nodeid':node,'body_unchanged':True,'assertions_unchanged':True,'assertion_count':row['assertion_count']})
(OUT/'original-body-checks.json').write_text(json.dumps(body_checks,indent=2)+'\n',encoding='utf8')

outcomes={}
summary=[]
for name,data in sorted(runs.items()):
 grouped=collections.defaultdict(list)
 for report in data['reports']:grouped[normalize(report['nodeid'])].append(report)
 outcomes[name]={node:outcome(reports) for node,reports in grouped.items()}
 selected=data['selected']
 worker_lists=list(data['worker_collections'].values())
 if worker_lists:
  assert all(ids==worker_lists[0] for ids in worker_lists),name
  selected=worker_lists[0]
 missing=set(map(normalize,selected))-set(grouped)
 durations=re.findall(r' in (\d+(?:\.\d+)?)s',decode(RAW/(name+'.log')))
 row={'name':name,'argv':data['argv'],'exit_code':data['exit_code'],'pytest_elapsed_seconds':float(durations[-1]) if durations else None,'plugin_wall_seconds':data['wall_seconds'],'selected_nodes':len(selected),'reported_nodes':len(grouped),'missing':sorted(missing),'outcomes':dict(collections.Counter(outcomes[name].values())),'phase_seconds':{phase:sum(r['seconds'] for r in data['reports'] if r['phase']==phase) for phase in ('setup','call','teardown')},'runtime_fixture_cache_hits':sum(value for r in data['reports'] if r['phase']=='teardown' for key,value in r.get('properties',[]) if key=='runtime_fixture_cache_hits')}
 for field in ['peak_tree_rss_bytes','sampled_cpu_seconds_lower_bound','observed_unique_processes','peak_observed_processes']:row[field]=data.get(field)
 summary.append(row)
(OUT/'runs.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')

with (OUT/'original-serial-ledger.tsv').open('w',encoding='utf8',newline='') as stream:
 writer=csv.writer(stream,delimiter='\t')
 run_names=sorted(runs)
 writer.writerow(['nodeid','tier','group','exclusive','cost_categories','isolation_reason',*run_names])
 for row in sorted(audit,key=lambda r:r['nodeid']):
  node=row['nodeid'];d=domains[node]
  writer.writerow([node,d['tier'],d['group'],d['exclusive'],';'.join(row['cost_categories']),d['reason'],*[outcomes[name].get(node,'NOT RUN') for name in run_names]])

final_names=['final-fast','final-core','final-exclusive','final-heavy','final-scale','final-optional']
final_outcomes={}
for name in final_names:
 for node,status in outcomes.get(name,{}).items():
  assert node not in final_outcomes,(node,'duplicate final selection')
  final_outcomes[node]=status
inventory=runs.get('final-exclusive',before)['collected']
original_inventory={node['nodeid'] for node in before['collected']}
current_inventory={node['nodeid'] for node in inventory}
assert not original_inventory-current_inventory,'original collected nodes removed'
required=set()
for node in inventory:
 markers=set(node['markers'])
 if not markers & {'performance','cuda','network','operator','environment_setup'}:required.add(node['nodeid'])
acceptance={'required_nodes':len(required),'run_legs':final_names,'missing_legs':[n for n in final_names if n not in runs],'missing_nodes':sorted(required-set(final_outcomes)),'extra_nodes':sorted(set(final_outcomes)-required),'outcomes':dict(collections.Counter(final_outcomes.values())),'failures':[node for node,status in final_outcomes.items() if status in ('FAILED','ERROR')],'skips':[node for node,status in final_outcomes.items() if status=='SKIPPED'],'original_serial_nodes':len(audit),'original_serial_missing_from_final':sorted({r['nodeid'] for r in audit}-set(final_outcomes))}
acceptance.update({'original_collected_nodes':len(original_inventory),'current_collected_nodes':len(current_inventory),'new_nodes':sorted(current_inventory-original_inventory),'original_collected_missing':sorted(original_inventory-current_inventory)})
failed_aggregate=bool(acceptance['missing_legs'] or acceptance['missing_nodes'] or acceptance['extra_nodes'] or acceptance['failures'] or acceptance['skips'] or any(runs[name]['exit_code'] for name in final_names if name in runs))
acceptance.update({'aggregate_status':'BLOCKED' if failed_aggregate else 'VERIFIED','aggregate_exit_code':int(failed_aggregate)})
(OUT/'acceptance.json').write_text(json.dumps(acceptance,indent=2)+'\n',encoding='utf8')
(OUT/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf8')
for name in ['environment.json','serial-audit-before.json','before-worker-receipts.json','startup.json','imports-unprofiled.json']:
 (OUT/name).write_bytes((RAW/name).read_bytes())
if (RAW/'optional-index.json').exists():(OUT/'optional-index.json').write_bytes((RAW/'optional-index.json').read_bytes())
for path in (RAW/'reduced').glob('before-*'):(OUT/path.name).write_bytes(path.read_bytes())

# Complete compressed raw logs/phase records. No model weights, caches or corpus files.
archive=OUT/'raw';archive.mkdir(exist_ok=True)
manifest=[]
for path in sorted(RAW.iterdir()):
 if not path.is_file() or path.suffix not in {'.json','.log','.exit','.py','.err','.pstats'}:continue
 if path.name in {'WORKING_NOTES.txt','build-evidence.log','build-evidence.exit'}:continue
 data=path.read_bytes();compressed=gzip.compress(data,mtime=0);target=archive/(path.name+'.gz');target.write_bytes(compressed)
 manifest.append({'name':path.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gzip_bytes':len(compressed),'gzip_sha256':hashlib.sha256(compressed).hexdigest()})
(OUT/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps(acceptance,indent=2))
for row in summary:print(row['name'],row['selected_nodes'],row['pytest_elapsed_seconds'],row['outcomes'])
