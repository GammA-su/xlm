﻿"""Reduce retained P30B pytest evidence without changing any test selection."""
import collections
import csv
import json
import re
from pathlib import Path
ROOT=Path.cwd()
RAW=ROOT/'artifacts/test-suite-perf-p30b'
OUT=RAW/'reduced'
OUT.mkdir(exist_ok=True)
audit=json.loads((RAW/'serial-audit-before.json').read_text())
by_node={r['nodeid']:r for r in audit}

def read_log(path):
 raw=path.read_bytes()
 return raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8',errors='replace')

def plain(node):
 return node.rsplit('@p30b-',1)[0]

def phases(data):
 nodes=collections.defaultdict(lambda: {'setup':0.,'call':0.,'teardown':0.,'outcomes':[]})
 for phase in data['reports']:
  node=nodes[plain(phase['nodeid'])]
  node[phase['phase']]+=phase['seconds']
  node['outcomes'].append(phase['phase']+':'+phase['outcome'])
 return dict(nodes)

summaries=[]
for path in sorted(RAW.glob('*.json')):
 data=json.loads(path.read_text(encoding='utf8'))
 if not isinstance(data,dict) or 'reports' not in data: continue
 nodes=phases(data)
 log=path.with_suffix('.log')
 elapsed=re.findall(r' in (\d+(?:\.\d+)?)s',read_log(log)) if log.exists() else []
 summary={'run':path.stem,'pytest_elapsed_seconds':float(elapsed[-1]) if elapsed else None,'plugin_wall_seconds':data['wall_seconds'],'exit_code':data['exit_code'],'nodes':len(nodes),'argv':data['argv'],'phase_seconds':{phase:sum(n[phase] for n in nodes.values()) for phase in ['setup','call','teardown']},'outcomes':dict(collections.Counter(n['outcomes'][-2] if len(n['outcomes'])==3 else '|'.join(n['outcomes']) for n in nodes.values()))}
 for field in ['peak_tree_rss_bytes','sampled_cpu_seconds_lower_bound','observed_unique_processes','peak_observed_processes']:
  summary[field]=data.get(field)
 summaries.append(summary)
 if path.stem=='before-serial':
  assert set(nodes)==set(by_node),(set(nodes)-set(by_node),set(by_node)-set(nodes))
  ordered=sorted(nodes,key=lambda n:sum(nodes[n][p] for p in ['setup','call','teardown']),reverse=True)
  columns=['nodeid','setup_seconds','call_seconds','teardown_seconds','total_phase_seconds','outcomes','cost_categories','isolation_audit']
  with (OUT/'before-serial-nodes.tsv').open('w',encoding='utf8',newline='') as stream:
   writer=csv.writer(stream,delimiter='\t');writer.writerow(columns)
   for node in ordered:
    n=nodes[node];writer.writerow([node,n['setup'],n['call'],n['teardown'],sum(n[p] for p in ['setup','call','teardown']),';'.join(n['outcomes']),';'.join(by_node[node]['cost_categories']),by_node[node]['isolation_audit']])
  lines=['# Original serial top 50','', 'Measured phase sums; setup/call/teardown remain separate. Cost tags are source-based, overlapping categories, not measured percentage attribution.','', '| Total s | Setup s | Call s | Teardown s | Node |', '|---:|---:|---:|---:|---|']
  for node in ordered[:50]:
   n=nodes[node];lines.append(f"| {sum(n[p] for p in ['setup','call','teardown']):.3f} | {n['setup']:.3f} | {n['call']:.3f} | {n['teardown']:.3f} | `{node}` |")
  modules=collections.defaultdict(lambda:collections.Counter())
  for node,n in nodes.items():
   m=modules[node.split('::')[0]];m['nodes']+=1
   for phase in ['setup','call','teardown']:m[phase]+=n[phase]
  lines+=['','## Module subtotals','','| Module | Nodes | Setup s | Call s | Teardown s |','|---|---:|---:|---:|---:|']
  for module,m in sorted(modules.items(),key=lambda x:-x[1]['call']):
   lines.append(f"| `{module}` | {m['nodes']} | {m['setup']:.3f} | {m['call']:.3f} | {m['teardown']:.3f} |")
  (OUT/'before-top50.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
(OUT/'runs.json').write_text(json.dumps(summaries,indent=2)+'\n',encoding='utf8')
for row in summaries: print(row['run'],row['nodes'],row['pytest_elapsed_seconds'],row['exit_code'])
