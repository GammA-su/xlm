﻿import ast
import csv
import hashlib
import json
from pathlib import Path
root=Path.cwd()
rows=list(csv.DictReader((root/'docs/implementation/evidence/P30/test-ledger.tsv').open(),delimiter='\t'))
result=[]
for row in rows:
 if row['tier']!='B': continue
 node=row['nodeid']; path, name=node.split('::',1); name=name.split('[',1)[0]
 source=(root/path).read_text(encoding='utf8'); tree=ast.parse(source)
 function=next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
 calls=sorted({ast.unparse(n.func) for n in ast.walk(function) if isinstance(n,ast.Call)})
 asserts=[ast.dump(n,include_attributes=False) for n in ast.walk(function) if isinstance(n,ast.Assert)]
 module=Path(path).stem
 heavy=name in {'test_public_two_source_prepare_direct_queue_and_resume','test_toy_campaign_runs_sequentially_to_success','test_offline_workflow_from_clean_environment','test_cli_resume_reconstructs_real_settings_and_exact_nonmultiple_budget','test_full_toy_run_reuses_on_repeat','test_partial_outputs_resume_without_redo'}
 exclusive=name=='test_timed_out_child_and_descendant_are_stopped'
 if module in {'test_cleaning_scheduler_v2','test_cleaning_throughput','test_dedup_small_oracles','test_dedup_throughput','test_parallel_tokens'}:
  group='process-pools'; domain='Bounded real process pools; private input/output paths; no shared pool. Group caps pool fan-out.'; costs=['process startup','actual algorithm work','artifact generation']
 elif module in {'test_acquisition_bounds','test_artifact_identity','test_frozen_recovery','test_sharded_datasets','test_prepare_bounds'}:
  group='owned-recovery'; domain='Private journals/locks and owned children only; loopback ports allocated with port 0 where used. Timing assertion remains exclusive.'; costs=['process startup','filesystem durability','sleep/poll timeout']
 elif module=='test_frozen_execution':
  group='frozen-contracts'; domain='Private snapshot copies/queues/ledgers; monkeypatches confined to worker process and undone; actual environment/package tests bypass identity reuse.'; costs=['environment inventory/hash','frozen execution fixture','queue/campaign','training fixture','subprocess CLI']
 elif module in {'test_queue','test_reports'}:
  group='queue-contracts' if not heavy else 'queue-campaign'; domain='Private tree/home/SQLite/lease files per test; real worker processes and cancellation thread are owned and joined.'; costs=['environment inventory/hash','frozen execution fixture','queue/campaign','training fixture']
 elif module=='test_configurable_workflow':
  group='two-source-'+('auxiliary' if '[True]' in node else 'baseline'); domain='Private authored tree, plugins, source documents, preparation, direct/queue/resume homes; captured A and mutated B both private.'; costs=['environment inventory/hash','queue/campaign','training fixture','subprocess CLI','model/tokenizer construction','artifact generation']
 elif module=='test_offline_workflow':
  group='offline-workflow' if heavy else 'prepare-contracts'; domain='Private explicit home and work/output tree; repository inputs read-only; fresh CLI processes retained.'; costs=['environment inventory/hash','subprocess CLI','training fixture','artifact generation']
 elif module=='test_prepare':
  group='prepare-contracts'; domain='Private home, output root, stage state and subprocess accounting; read-only authored source fixtures.'; costs=['subprocess CLI','artifact generation','actual algorithm work']
 else:
  group=module.removeprefix('test_').replace('_','-'); domain='Private per-test output/home (demo uses TemporaryDirectory); subprocess boundaries retained; in-process monkeypatches are worker-local.'; costs=['process startup','environment inventory/hash','training fixture','subprocess CLI']
 result.append(dict(nodeid=node, proposed_tier='serial_heavy' if heavy else 'serial_core', proposed_group=group, exclusive=exclusive, isolation_audit=domain, cost_categories=costs, direct_calls=calls, assertion_count=len(asserts), assertions_sha256=hashlib.sha256('\n'.join(asserts).encode()).hexdigest(), body_sha256=hashlib.sha256(ast.dump(ast.Module(body=function.body,type_ignores=[]),include_attributes=False).encode()).hexdigest()))
(root/'artifacts/test-suite-perf-p30b/serial-audit-before.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('Original nodes:',len(result),'heavy:',sum(r['proposed_tier']=='serial_heavy' for r in result),'exclusive:',sum(r['exclusive'] for r in result))
