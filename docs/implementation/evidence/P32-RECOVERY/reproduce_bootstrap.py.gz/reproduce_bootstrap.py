import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "baseline/src"))
import pytest

raise SystemExit(pytest.main([
    "tests/test_p32_orphans.py::test_initial_journal_bytes_are_bounded_before_first_write",
    "-n", "0", "-q", "--basetemp", "artifacts/p32-recovery/pytest-bootstrap-before",
]))
