import gzip
import hashlib
import json
import struct
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / "artifacts/p32-heavy-crash"
for name in ("gate-heavy.log", "gate-heavy.json", "gate-heavy.run.json"):
    source = ROOT / "docs/implementation/evidence/P32-RECOVERY" / (name + ".gz")
    (OUT / ("original-" + name)).write_bytes(gzip.decompress(source.read_bytes()))
d = (OUT / "original-python-36048.dmp").read_bytes()
u32 = lambda offset: struct.unpack_from("<I", d, offset)[0]
u64 = lambda offset: struct.unpack_from("<Q", d, offset)[0]
count, directory = u32(8), u32(12)
streams = {}
for index in range(count):
    kind, size, rva = struct.unpack_from("<III", d, directory + index * 12)
    streams[kind] = (size, rva)
modules = []
base = streams[4][1]
for index in range(u32(base)):
    item = base + 4 + index * 108
    name = u32(item + 20)
    modules.append({"base": u64(item), "size": u32(item + 8), "timestamp": u32(item + 16),
                    "name": d[name + 4:name + 4 + u32(name)].decode("utf-16-le")})
exception = streams[6][1]
context = u32(exception + 164)
exception_address = u64(exception + 24)
module = next(m for m in modules if m["base"] <= exception_address < m["base"] + m["size"])
result = {"streams": streams, "thread_id": u32(exception), "thread_hex": hex(u32(exception)),
          "exception_code": hex(u32(exception + 8)), "address": hex(exception_address),
          "module": module, "offset": hex(exception_address - module["base"]),
          "parameters": [hex(u64(exception + 40 + 8*i)) for i in range(u32(exception + 32))],
          "rip": hex(u64(context + 248)), "rsp": hex(u64(context + 152))}

pe = Path(module["name"]).read_bytes()
peoff = struct.unpack_from("<I", pe, 0x3c)[0]
assert struct.unpack_from("<I",pe,peoff+8)[0] == module["timestamp"]
result["module_sha256"] = hashlib.sha256(pe).hexdigest()
result["module_timestamp_matches_dump"] = True
sections = struct.unpack_from("<H", pe, peoff + 6)[0]
optsize = struct.unpack_from("<H", pe, peoff + 20)[0]
def rva_offset(rva):
    for i in range(sections):
        sec = peoff + 24 + optsize + i*40
        virtual_size, virtual, rawsize, raw = struct.unpack_from("<IIII", pe, sec+8)
        if virtual <= rva < virtual + max(virtual_size, rawsize):
            return raw + rva - virtual
    raise ValueError(rva)
exports = rva_offset(struct.unpack_from("<I", pe, peoff+24+112)[0])
functions, names = struct.unpack_from("<II", pe, exports+20)
funcrva, namerva, ordrva = struct.unpack_from("<III", pe, exports+28)
symbols = []
for i in range(names):
    nameoff = rva_offset(struct.unpack_from("<I", pe, rva_offset(namerva)+4*i)[0])
    ordinal = struct.unpack_from("<H", pe, rva_offset(ordrva)+2*i)[0]
    address = struct.unpack_from("<I", pe, rva_offset(funcrva)+4*ordinal)[0]
    name = pe[nameoff:pe.index(b"\0", nameoff)].decode()
    symbols.append((address, name))
symbols.sort()
offset = exception_address-module["base"]
result["nearest_exports"] = [(hex(a), n, offset-a) for a,n in sorted(symbols, key=lambda x:abs(x[0]-offset))[:12]]
result["traceback_exports"] = [(hex(a),n) for a,n in symbols if "Traceback" in n or "Fatal" in n]
result["registers"] = {n: hex(u64(context + off)) for n,off in
                       (("rax",120),("rcx",128),("rdx",136),("rbx",144),
                        ("rbp",160),("rsi",168),("rdi",176),("r8",184),("r9",192))}
result["fault_instruction_bytes"] = pe[rva_offset(offset):rva_offset(offset)+24].hex()
pdata,pdata_size=struct.unpack_from("<II",pe,peoff+24+112+8*3)
for index in range(pdata_size//12):
    begin,end,unwind=struct.unpack_from("<III",pe,rva_offset(pdata)+index*12)
    if begin<=offset<end:
        result["fault_function_range"]={"begin":hex(begin),"end":hex(end),"unwind":hex(unwind)}
base = streams[5][1]
memory = [(u64(base+4+16*i), u32(base+4+16*i+8), u32(base+4+16*i+12)) for i in range(u32(base))]
def read_memory(address, size):
    for start,length,rva in memory:
        if start <= address and address+size <= start+length:
            return d[rva+address-start:rva+address-start+size]
    return b""
stack = b"".join(read_memory(u64(context+152)+i,8) for i in range(0,2048,8))
result["stack_python_addresses"] = []
for i in range(0,len(stack),8):
    address = struct.unpack_from("<Q",stack,i)[0]
    if module["base"] <= address < module["base"]+module["size"]:
        relative = address-module["base"]
        previous = max((s for s in symbols if s[0]<=relative), default=(0,"?"))
        result["stack_python_addresses"].append({"stack_offset":i,"rva":hex(relative),
            "preceding_export":previous[1],"delta":relative-previous[0]})
# Native thread contexts establish whether the exception belongs to the Python
# test thread or the separate timeout-dump watchdog thread.
base = streams[3][1]
result["threads"] = []
for i in range(u32(base)):
    item = base + 4 + 48*i
    ctx = u32(item+44)
    rip = u64(ctx+248)
    m = next((m for m in modules if m["base"] <= rip < m["base"]+m["size"]), None)
    result["threads"].append({"id": hex(u32(item)), "rip": hex(rip),
                              "module": m["name"] if m else None,
                              "offset": hex(rip-m["base"]) if m else None})
(OUT / "native-summary.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
