"""Fixed three trials: stdlib paths plus native timeout dumps, no XLM imports."""
import faulthandler
import json
import subprocess
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent
if len(sys.argv)>1:
    faulthandler.enable()
    root = Path("G:/authored")
    paths = [root / str(i) / "payload.bin" for i in range(64)]
    faulthandler.dump_traceback_later(0.001, repeat=True)
    deadline = time.monotonic()+15
    iterations = 0
    while time.monotonic()<deadline:
        for path in paths:
            str(path.relative_to(root))
        iterations += 1
    faulthandler.cancel_dump_traceback_later()
    print("iterations", iterations)
else:
    rows=[]
    for trial in range(1,4):
        log=OUT/f"native-watchdog-{trial}.log"
        with log.open("xb") as stream:
            run = subprocess.run([sys.executable,"-X","dev",__file__,"child"],
                                 stdout=stream,stderr=subprocess.STDOUT,timeout=25)
        rows.append({"trial":trial,"exit":run.returncode,"log_bytes":log.stat().st_size})
        (OUT/"native-watchdog-results.json").write_text(json.dumps(rows,indent=2))
        print(rows[-1],flush=True)
